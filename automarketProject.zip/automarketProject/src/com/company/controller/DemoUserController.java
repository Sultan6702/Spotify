package com.company.controller;

import com.company.model.entities.Song;
import com.company.model.repositories.IDemoClientRepository;

import java.util.ArrayList;

public class DemoUserController {

    private final IDemoClientRepository repository;

    public DemoUserController(IDemoClientRepository repository) {
        this.repository = repository;
    }

    public ArrayList<Song> getAllSongs(){
        return repository.getSongs();
    }

    public ArrayList < Song > getSongsOf(int id){
        return repository.getSongsOf(id);
    }
}
