package com.company.controller;

import com.company.model.entities.Song;
import com.company.model.repositories.IProUserRepository;

import java.util.ArrayList;

public class ProUserController {

    private final IProUserRepository repository;

    public ProUserController(IProUserRepository repository) {
        this.repository = repository;
    }

    public ArrayList<Song> getAllSongs(){
        return repository.getSongs();
    }


    public ArrayList < Song > getSongsOf(int id){
        return repository.getSongsOf(id);
    }

    public void addSong(int id, String name){
        repository.addSong(id, name);
    }

}
