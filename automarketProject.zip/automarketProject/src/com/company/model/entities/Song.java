package com.company.model.entities;

public class Song {
    private int id;
    private String name;
    private float duration;
    private boolean subscription;

    public Song(int id, String name, float duration, boolean subscription) {
        this.id = id;
        this.name = name;
        this.duration = duration;
        this.subscription = subscription;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public boolean isSubscription() {
        return subscription;
    }

    public void setSubscription(boolean subscription) {
        this.subscription = subscription;
    }

    @Override
    public String toString() {
        return "Song{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                ", subscription=" + subscription +
                '}';
    }
}
