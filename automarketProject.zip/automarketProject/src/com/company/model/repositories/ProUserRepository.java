package com.company.model.repositories;

import com.company.model.database.IDB;
import com.company.model.entities.Song;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ProUserRepository implements IProUserRepository{

    private final IDB db;

    public ProUserRepository(IDB db) {
        this.db = db;
    }

    public ArrayList<Song> getSongs(){

        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        ArrayList<Song> res = new ArrayList<>();

        try {

            con = db.getConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from songs");

            while(rs.next()){
                res.add(new Song(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getBoolean(4)));
            }

            return res;

        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }

        return null;
    }

    public void addSong(int id, String name){
        Connection con = null;


        try {
            con = db.getConnection();
            String sql = "insert into songuser values (?, ?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);
            st.setString(2, name);

            st.execute();



        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }
    }

    public ArrayList < Song > getSongsOf(int id){
        Connection con = null;
        ResultSet rs = null;

        try {
            con = db.getConnection();
            String sql = "select * from songuser where id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ArrayList < Song > songs = new ArrayList<>();

            rs = st.executeQuery();

            while(rs.next()){
                songs.add(new Song(0, rs.getString(2), 0, false));
            }

            return songs;


        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }
        return null;
    }

}
