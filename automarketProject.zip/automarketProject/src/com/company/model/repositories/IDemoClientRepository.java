package com.company.model.repositories;

import com.company.model.entities.Song;

import java.util.ArrayList;

public interface IDemoClientRepository {
    void addSong(int id, String name);

    ArrayList<Song> getSongs();

    ArrayList < Song > getSongsOf(int id);
}
