package com.company.view;

import com.company.controller.DemoUserController;
import com.company.controller.ProUserController;
import com.company.model.entities.Song;
import com.company.model.repositories.DemoClientRepository;
import com.company.model.repositories.IDemoClientRepository;
import com.company.model.repositories.IProUserRepository;

import java.util.ArrayList;
import java.util.Scanner;

public class Application {

    private DemoUserController demoUserController;
    private ProUserController proUserController;

    public Application(IDemoClientRepository demoClientRepository, IProUserRepository proUserRepository){
        demoUserController = new DemoUserController(demoClientRepository);
        proUserController = new ProUserController(proUserRepository);
    }


    public void start(){
        System.out.println("Welcome to Spotify");

        Scanner scan = new Scanner(System.in);

        while(true){
            System.out.println("1: I am a pro user");
            System.out.println("2: I am a demo user");

            int userChoice = scan.nextInt();

            if(userChoice == 1){

                System.out.println("Input your id");

                int id = scan.nextInt();

                System.out.println("1: Show all songs");
                System.out.println("2: Add songs to my list");
                System.out.println("3: Show my songs");

                userChoice = scan.nextInt();

                if(userChoice == 1){
                    ShowAllSongsPro();
                } else if(userChoice == 2){
                    System.out.println("Input name of song");
                    String name = scan.next();

                    addSong(id, name);

                } else if(userChoice == 3){
                    showSongsOfPro(id);
                }

            } else if(userChoice == 2){

                int id;

                System.out.println("Enter your id");

                id = scan.nextInt();


                System.out.println("1: Show all songs");
                System.out.println("2: Add songs to my list");
                System.out.println("3: Show my songs");

                userChoice = scan.nextInt();

                if(userChoice == 1){
                    ShowAllSongsDemo();
                } else if(userChoice == 2){
                    System.out.println("Input name of song");
                    String name = scan.next();

                    addSong(id, name);

                } else if(userChoice == 3){
                    showSongsOfDemo(id);
                }
            }

        }

    }
    void ShowAllSongsDemo(){
        ArrayList<Song> songs = demoUserController.getAllSongs();

        for(Song s : songs){
            System.out.println(s.toString());
        }
    }

    void ShowAllSongsPro(){
        ArrayList<Song> songs = proUserController.getAllSongs();

        for(Song s : songs){
            System.out.println(s.toString());
        }
    }

    void showSongsOfDemo(int id){
        ArrayList < Song > songs = demoUserController.getSongsOf(id);

        for(Song to : songs){
            System.out.println(to.toString());
        }
    }

    void showSongsOfPro(int id){
        ArrayList < Song > songs = proUserController.getSongsOf(id);

        for(Song to : songs){
            System.out.println(to.toString());
        }
    }

    void addSong(int id, String name){
        proUserController.addSong(id, name);
    }




}
