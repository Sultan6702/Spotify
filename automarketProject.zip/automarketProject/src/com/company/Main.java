package com.company;

import com.company.model.database.IDB;
import com.company.model.database.Postgres;
import com.company.model.repositories.DemoClientRepository;
import com.company.model.repositories.IDemoClientRepository;
import com.company.model.repositories.IProUserRepository;
import com.company.model.repositories.ProUserRepository;
import com.company.view.Application;

public class Main {

    public static void main(String[] args) {

        IDB database = new Postgres();

        IProUserRepository iProUserRepository = new ProUserRepository(database);
        IDemoClientRepository iDemoClientRepository = new DemoClientRepository(database);

        Application app = new Application(iDemoClientRepository, iProUserRepository);

        app.start();

    }

}
